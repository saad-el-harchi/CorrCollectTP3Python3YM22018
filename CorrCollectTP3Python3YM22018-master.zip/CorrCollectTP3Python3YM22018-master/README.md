# CorrCollectTP3Python3YM22018

Exercice 1 : Abderrahmane

Exercice 2 : 

A --> Ichrac

B --> Loubna

C --> Yahya

D --> Loïc

E --> Mohamed

F --> Imane

G --> Moussa

H --> Hamza

I --> Ayman

Exercice 3 : Saad

Exercice 4 : Ayman, el arbi et Mohamed
